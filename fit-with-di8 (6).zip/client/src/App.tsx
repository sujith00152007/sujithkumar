import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/signin"} component={Home} />
      <Route path={"/dashboard"} component={Home} />
      <Route path={"/workouts"} component={Home} />
      <Route path={"/nutrition"} component={Home} />
      <Route path={"/nutrition/diet"} component={Home} />
      <Route path={"/nutrition/daily-intake"} component={Home} />
      <Route path={"/nutrition/daily-intake-guide"} component={Home} />
      <Route path={"/scanners"} component={Home} />
      <Route path={"/scanners/food"} component={Home} />
      <Route path={"/scanners/body"} component={Home} />
      <Route path={"/scanners/supplement"} component={Home} />
      <Route path={"/progress"} component={Home} />
      <Route path={"/mind-map"} component={Home} />
      <Route path={"/profile"} component={Home} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
