import { useMemo, useState } from "react";
import {
  ArrowRight,
  BrainCircuit,
  Calculator,
  ChevronRight,
  Dumbbell,
  Flame,
  Info,
  Leaf,
  Loader2,
  ScanLine,
  Target,
  Utensils,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

const iconForKind = (kind: string) => {
  if (kind === "category" || kind === "path") return Dumbbell;
  if (kind === "tool" || kind === "calculator") return ScanLine;
  if (kind === "macro") return Leaf;
  if (kind === "principle" || kind === "outcome") return Target;
  if (kind === "section") return Utensils;
  return BrainCircuit;
};

export default function MindMap() {
  const [selectedId, setSelectedId] = useState("overview");
  const [heightCm, setHeightCm] = useState("175");
  const [weightKg, setWeightKg] = useState("75");
  const [goal, setGoal] = useState<"fat_loss" | "muscle_gain" | "maintenance">("maintenance");
  const [activityLevel, setActivityLevel] = useState<"light" | "moderate" | "high">("moderate");
  const [calculator, setCalculator] = useState<"bmi" | "nutrition">("bmi");

  const mapQuery = trpc.fitness.mindMap.useQuery();
  const allWorkoutsInput = useMemo(() => ({ category: "all" }), []);
  const workoutsQuery = trpc.fitness.workouts.list.useQuery(allWorkoutsInput);
  const bmiMutation = trpc.fitness.calculators.bmi.useMutation();
  const nutritionMutation = trpc.fitness.calculators.nutrition.useMutation();

  const nodes = mapQuery.data?.nodes ?? [];
  const selected = nodes.find(node => node.id === selectedId) ?? nodes[0];
  const children = nodes.filter(node => node.parentId === selected?.id);
  const selectedPath = selected
    ? nodes
        .filter(node => node.id === selected.id || node.parentId === selected.id)
        .slice(0, 4)
    : [];

  const calculate = () => {
    const height = Number(heightCm);
    const weight = Number(weightKg);
    if (!Number.isFinite(height) || !Number.isFinite(weight)) return;
    if (calculator === "bmi") {
      bmiMutation.mutate({ heightCm: height, weightKg: weight });
    } else {
      nutritionMutation.mutate({ weightKg: weight, goal, activityLevel });
    }
  };

  if (mapQuery.isLoading) {
    return <div className="mindmap-loading"><Loader2 className="spin" size={18} /> Loading your performance map...</div>;
  }

  return (
    <section className="mindmap-page">
      <div className="page-heading mindmap-heading">
        <div>
          <div className="eyebrow"><span className="pulse" /> SYSTEM MAP / BACKEND CONNECTED</div>
          <h1>Information architecture<span className="red">.</span></h1>
          <p>Move from the handwritten plan to a navigable performance system.</p>
        </div>
        <div className="mindmap-status"><span className="pulse" /> LIVE DATA LAYER</div>
      </div>

      <div className="mindmap-layout">
        <div className="mindmap-canvas panel">
          <div className="mindmap-canvas-head">
            <div><span className="eyebrow red-text">DI8 PERFORMANCE MIND MAP</span><h2>Follow the signal.</h2></div>
            <span className="mindmap-count">{nodes.length} nodes</span>
          </div>
          <div className="mindmap-root-line">
            <div className="mindmap-node root-node" onClick={() => setSelectedId("overview")} role="button" tabIndex={0} onKeyDown={event => event.key === "Enter" && setSelectedId("overview")}>
              <BrainCircuit size={18} /><span>Overview</span><small>performance system</small>
            </div>
            <div className="mindmap-connector" />
          </div>
          <div className="mindmap-branches">
            {nodes.filter(node => node.parentId === "overview").map(node => {
              const Icon = iconForKind(node.kind);
              const isActive = selected?.id === node.id;
              return <button className={`mindmap-node branch-node ${isActive ? "selected" : ""}`} key={node.id} onClick={() => setSelectedId(node.id)}>
                <Icon size={15} /><span>{node.label}</span><ChevronRight size={13} className="node-arrow" />
              </button>;
            })}
          </div>
          <div className="mindmap-detail-grid">
            <div className="mindmap-detail panel-inset">
              <span className="eyebrow">SELECTED BRANCH</span>
              <h3>{selected?.label ?? "Overview"}</h3>
              <p>{selected?.description ?? "Select a branch to inspect its purpose."}</p>
              <div className="mindmap-children">
                {children.length ? children.map(child => {
                  const Icon = iconForKind(child.kind);
                  return <button key={child.id} onClick={() => setSelectedId(child.id)}><Icon size={14} /><span>{child.label}</span><ArrowRight size={13} /></button>;
                }) : <span className="empty-note">This node is an endpoint. Use the calculator and scanner tools to make it actionable.</span>}
              </div>
            </div>
            <div className="mindmap-path panel-inset">
              <span className="eyebrow">CURRENT PATH</span>
              <div className="path-stack">
                {selectedPath.map((node, index) => <button key={`${node.id}-${index}`} onClick={() => setSelectedId(node.id)}><span>{String(index + 1).padStart(2, "0")}</span>{node.label}</button>)}
              </div>
              <div className="path-note"><Info size={14} /> Every branch maps to a future data source, workflow, or metric.</div>
            </div>
          </div>
        </div>

        <aside className="mindmap-side">
          <div className="panel backend-panel">
            <div className="panel-top"><div><span className="eyebrow">BACKEND SIGNALS</span><h3>Data layer status</h3></div><span className="live-badge"><i /> LIVE</span></div>
            <div className="backend-stats"><div><strong>{workoutsQuery.data?.length ?? 0}</strong><span>workout protocols</span></div><div><strong>6</strong><span>data domains</span></div><div><strong>100%</strong><span>typed API</span></div></div>
            <div className="backend-note"><Dumbbell size={14} /> {workoutsQuery.isLoading ? "Syncing workout library..." : "Workout library synced from the database."}</div>
          </div>

          <div className="panel calculator-panel">
            <div className="panel-top"><div><span className="eyebrow">DECISION TOOLS</span><h3>Make the map measurable</h3></div><Calculator size={17} className="muted-icon" /></div>
            <div className="calculator-tabs"><button className={calculator === "bmi" ? "active" : ""} onClick={() => setCalculator("bmi")}>BMI</button><button className={calculator === "nutrition" ? "active" : ""} onClick={() => setCalculator("nutrition")}>Nutrition</button></div>
            <div className="calculator-fields"><label>HEIGHT (CM)<input value={heightCm} onChange={event => setHeightCm(event.target.value)} inputMode="decimal" /></label><label>WEIGHT (KG)<input value={weightKg} onChange={event => setWeightKg(event.target.value)} inputMode="decimal" /></label></div>
            {calculator === "nutrition" && <div className="calculator-fields"><label>GOAL<select value={goal} onChange={event => setGoal(event.target.value as typeof goal)}><option value="fat_loss">Fat loss</option><option value="muscle_gain">Muscle gain</option><option value="maintenance">Maintenance</option></select></label><label>ACTIVITY<select value={activityLevel} onChange={event => setActivityLevel(event.target.value as typeof activityLevel)}><option value="light">Light</option><option value="moderate">Moderate</option><option value="high">High</option></select></label></div>}
            <button className="btn full-width calculator-submit" onClick={calculate} disabled={bmiMutation.isPending || nutritionMutation.isPending}><Flame size={14} />{bmiMutation.isPending || nutritionMutation.isPending ? "Calculating..." : `Calculate ${calculator === "bmi" ? "BMI" : "targets"}`}<ArrowRight size={14} /></button>
            {bmiMutation.data && calculator === "bmi" && <div className="result-card"><span className="eyebrow">BMI RESULT</span><strong>{bmiMutation.data.bmi}</strong><b>{bmiMutation.data.category}</b><small>Healthy directional range: {bmiMutation.data.healthyWeightRangeKg.min}–{bmiMutation.data.healthyWeightRangeKg.max} kg</small></div>}
            {nutritionMutation.data && calculator === "nutrition" && <div className="result-card nutrition-result"><span className="eyebrow">DAILY TARGETS</span><strong>{nutritionMutation.data.calories} <small>KCAL</small></strong><div><b>{nutritionMutation.data.proteinGrams}g</b> protein <b>{nutritionMutation.data.carbGrams}g</b> carbs <b>{nutritionMutation.data.fatGrams}g</b> fat</div><small>{nutritionMutation.data.fibreGrams}g fibre target</small></div>}
          </div>
        </aside>
      </div>

      <div className="mindmap-footnote"><span><ScanLine size={14} /> Food scanner</span><span><Target size={14} /> Body scanner</span><span><Calculator size={14} /> BMI calculator</span><span><Leaf size={14} /> Diet knowledge</span><span className="footnote-copy">Public calculators work without login; personal logs save securely after OAuth sign-in.</span></div>
    </section>
  );
}
