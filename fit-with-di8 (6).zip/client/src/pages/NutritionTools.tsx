import { useMemo, useState } from "react";
import { AlertTriangle, ArrowRight, Check, ClipboardList, Dumbbell, FlaskConical, Info, Leaf, Loader2, ShieldCheck, Target, Utensils } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

const knowledgeFallback = [
  { slug: "calorie-deficit", title: "Calorie deficit", summary: "Eating fewer calories than you use over time can support weight loss.", guidance: "Start conservatively, keep protein adequate, train consistently, and review trends over several weeks." },
  { slug: "calorie-surplus", title: "Calorie surplus", summary: "Eating more calories than you use can support body-mass gain.", guidance: "Prefer a measured surplus with progressive training so more of the gain can come from lean tissue." },
  { slug: "weight-gain", title: "Weight gain", summary: "Body weight increases when average energy intake exceeds expenditure.", guidance: "Track weekly averages, strength progress, appetite, digestion, and recovery—not one daily weigh-in." },
  { slug: "fat-loss", title: "Fat loss", summary: "Fat loss is the reduction of stored body fat, usually through a sustained energy deficit.", guidance: "Use a realistic pace, preserve resistance training, prioritize protein, sleep, and adherence." },
  { slug: "weight-loss", title: "Weight loss", summary: "Weight loss includes changes in water, glycogen, food volume, muscle, and fat.", guidance: "Look at multi-week trends and waist measurements to avoid overreacting to normal fluctuations." },
  { slug: "body-recomposition", title: "Body recomposition", summary: "Recomposition aims to reduce fat while maintaining or increasing lean mass.", guidance: "It is more gradual: combine resistance training, adequate protein, recovery, and calories near maintenance." },
] as const;

const dailyIntakeGuides = [
  { name: "Protein", amount: "About 1.2–2.0 g/kg/day", note: "Active people often benefit from the higher end; distribute across meals and adjust for health needs." },
  { name: "Carbohydrates", amount: "About 45–65% of daily energy", note: "Choose portions based on activity, training volume, preference, and total calorie needs." },
  { name: "Fat", amount: "About 20–35% of daily energy", note: "Include varied unsaturated sources; do not treat a percentage as a prescription." },
  { name: "Fibre", amount: "About 25–38 g/day", note: "Increase gradually with fluids using vegetables, fruit, legumes, whole grains, nuts, and seeds." },
  { name: "Micronutrients", amount: "Vitamins and minerals from variety", note: "Prioritize a diverse diet; supplements are not automatically safer or better than food." },
] as const;

export default function NutritionTools({ initialTab = "knowledge", standaloneScanner = false }: { initialTab?: "body" | "supplement" | "knowledge" | "calculator" | "daily-intake"; standaloneScanner?: boolean }) {
  const [tab, setTab] = useState<typeof initialTab>(initialTab);
  const [height, setHeight] = useState("175");
  const [weight, setWeight] = useState("75");
  const [bodyFat, setBodyFat] = useState("18");
  const [waist, setWaist] = useState("82");
  const [supplementName, setSupplementName] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [bodyImage, setBodyImage] = useState<string | null>(null);
  const [supplementImage, setSupplementImage] = useState<string | null>(null);
  const [age, setAge] = useState("30");
  const [sex, setSex] = useState<"female" | "male" | "unspecified">("unspecified");
  const [activityLevel, setActivityLevel] = useState<"light" | "moderate" | "high">("moderate");
  const [goal, setGoal] = useState<"weight_gain" | "fat_loss" | "maintenance" | "body_recomposition">("maintenance");
  const nutritionMutation = trpc.fitness.calculators.nutrition.useMutation();
  const bodyMutation = trpc.fitness.scanners.bodyEstimate.useMutation();
  const supplementMutation = trpc.fitness.scanners.supplementAnalyze.useMutation();
  const supplementOcrMutation = trpc.fitness.scanners.supplementOcr.useMutation({
    onSuccess: result => {
      if (result.productName && !supplementName) setSupplementName(result.productName);
      setIngredients(result.ingredients.join(", "));
      toast(`Label text extracted (${result.confidence} confidence). Review it before screening.`);
    },
    onError: error => toast(error.message || "Could not read this label. You can still paste the ingredients manually."),
  });
  const saveScan = trpc.fitness.logs.bodyScan.useMutation({ onSuccess: () => toast("Body scan saved to your progress log.") });
  const knowledgeQuery = trpc.fitness.nutritionKnowledge.useQuery();
  const { isAuthenticated } = useAuth();
  const knowledge = knowledgeQuery.data ?? knowledgeFallback;
  const selectedResult = useMemo(() => bodyMutation.data, [bodyMutation.data]);

  const readImage = (file: File, setter: (value: string) => void) => {
    if (!file.type.startsWith("image/")) { toast("Please choose an image file."); return; }
    if (file.size > 8_000_000) { toast("Please choose an image smaller than 8 MB."); return; }
    const reader = new FileReader();
    reader.onload = () => setter(String(reader.result));
    reader.readAsDataURL(file);
  };

  const runBodyScan = () => {
    bodyMutation.mutate({ heightCm: Number(height), weightKg: Number(weight), bodyFatPercent: Number(bodyFat), waistCm: Number(waist) });
  };
  const runNutritionCalculator = () => {
    const mappedGoal = goal === "weight_gain" ? "muscle_gain" : goal;
    nutritionMutation.mutate({ age: Number(age), sex, heightCm: Number(height), weightKg: Number(weight), activityLevel, goal: mappedGoal });
  };

  const runSupplementScan = () => {
    supplementMutation.mutate({ name: supplementName || "Unknown supplement", ingredients });
  };
  const handleSupplementFile = (file: File) => {
    if (!file.type.startsWith("image/")) { toast("Please choose an image file."); return; }
    if (file.size > 8_000_000) { toast("Please choose an image smaller than 8 MB."); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const imageDataUrl = String(reader.result);
      setSupplementImage(imageDataUrl);
      supplementOcrMutation.mutate({ imageDataUrl });
    };
    reader.readAsDataURL(file);
  };

  return <section className="nutrition-tools-page">
    <div className="page-heading inner-heading"><div><div className="eyebrow"><span className="pulse" /> NUTRITION INTELLIGENCE / 02</div><h1>Know what goes in<span className="red">.</span></h1><p>Estimate body composition, screen supplement labels, and learn the fundamentals behind the numbers.</p></div><div className="nutrition-safety"><ShieldCheck size={14} /> ESTIMATES WITH CONTEXT</div></div>
    {!standaloneScanner && <div className="nutrition-tabs"><button className={tab === "knowledge" ? "active" : ""} onClick={() => setTab("knowledge")}><Leaf size={15} /> Diet knowledge</button><button className={tab === "calculator" ? "active" : ""} onClick={() => setTab("calculator")}><Target size={15} /> Daily requirements</button><button className={tab === "daily-intake" ? "active" : ""} onClick={() => setTab("daily-intake")}><Utensils size={15} /> Daily intake guide</button></div>}

    {tab === "body" && <div className="nutrition-feature-grid"><div className="panel nutrition-form-panel"><div className="panel-top"><div><span className="eyebrow red-text">BODY SCANNER / COMPOSITION</span><h2>Find your lean signal.</h2></div><ClipboardList size={18} className="muted-icon" /></div><p className="feature-copy">Upload a suitable full-body image for reference, then add measurements from a consistent method. The analysis estimates lean mass, fat mass, BMI, and a waist-to-height signal.</p><label className="upload-drop"><input type="file" accept="image/*" onChange={e => e.target.files?.[0] && readImage(e.target.files[0], value => setBodyImage(value))} /><Dumbbell size={18} /><span>{bodyImage ? "Body image ready for analysis" : "Upload full-body image"}</span><small>JPG, PNG · max 8 MB · optional reference</small></label>{bodyImage && <img className="scan-preview" src={bodyImage} alt="Uploaded body scan reference" />}<div className="tool-form-grid"><label>HEIGHT (CM)<input value={height} onChange={e => setHeight(e.target.value)} inputMode="decimal" /></label><label>WEIGHT (KG)<input value={weight} onChange={e => setWeight(e.target.value)} inputMode="decimal" /></label><label>BODY FAT (%)<input value={bodyFat} onChange={e => setBodyFat(e.target.value)} inputMode="decimal" /></label><label>WAIST (CM)<input value={waist} onChange={e => setWaist(e.target.value)} inputMode="decimal" /></label></div><button className="btn full-width" onClick={runBodyScan} disabled={bodyMutation.isPending}><Dumbbell size={14} /> {bodyMutation.isPending ? "Reading signals..." : "Analyze body composition"}<ArrowRight size={14} /></button><div className="tool-disclaimer"><Info size={14} /> Bioimpedance, tape, and visual estimates can be inaccurate. Track the same method over time; consult a qualified professional for clinical assessment.</div></div><div className="panel result-panel">{selectedResult ? <><span className="eyebrow">LATEST ESTIMATE</span><div className="metric-big"><strong>{selectedResult.bodyFatPercent}%</strong><span>body fat</span></div><div className="metric-list"><div><span>Lean mass</span><b>{selectedResult.leanMassKg} kg</b></div><div><span>Fat mass</span><b>{selectedResult.fatMassKg} kg</b></div><div><span>BMI</span><b>{selectedResult.bmi}</b></div><div><span>Waist / height</span><b>{selectedResult.waistToHeightRatio}</b></div></div><div className="signal-callout"><Check size={14} /> {selectedResult.interpretation}</div><button className="btn btn-dark full-width" onClick={() => isAuthenticated ? saveScan.mutate({ bodyFatPercent: selectedResult.bodyFatPercent, leanMassKg: selectedResult.leanMassKg, hydrationPercent: selectedResult.hydrationPercent, source: "manual" }) : startLogin()}><Check size={14} /> {isAuthenticated ? "Save to progress" : "Sign in to save"}</button></> : <div className="empty-tool"><Dumbbell size={25} /><h3>Your results appear here</h3><p>Enter your measurements to estimate body fat and lean mass signals.</p></div>}</div></div>}

    {tab === "supplement" && <div className="nutrition-feature-grid"><div className="panel nutrition-form-panel"><div className="panel-top"><div><span className="eyebrow red-text">SUPPLEMENT SCANNER / LABEL REVIEW</span><h2>Read beyond the front label.</h2></div><FlaskConical size={18} className="muted-icon" /></div><p className="feature-copy">Upload a label/package image to extract readable text automatically, then review or correct the ingredient panel before screening.</p><label className="upload-drop compact-upload"><input type="file" accept="image/*" onChange={e => e.target.files?.[0] && handleSupplementFile(e.target.files[0])} /><FlaskConical size={18} />{supplementOcrMutation.isPending ? <><span>Reading label text...</span><small>Vision OCR is extracting ingredients and serving details</small></> : <><span>{supplementImage ? "Label image ready for review" : "Upload label or package image"}</span><small>Automatic OCR · JPG, PNG, WebP · max 8 MB</small></>}</label>{supplementImage && <img className="label-preview" src={supplementImage} alt="Uploaded supplement label" />}<label className="wide-label">PRODUCT NAME<input value={supplementName} onChange={e => setSupplementName(e.target.value)} placeholder="Example: Pre-workout / whey isolate" /></label><label className="wide-label">INGREDIENT PANEL<textarea value={ingredients} onChange={e => setIngredients(e.target.value)} placeholder="OCR results appear here. Review or paste ingredients manually..." rows={8} /></label><button className="btn full-width" onClick={runSupplementScan} disabled={!ingredients.trim() || supplementMutation.isPending || supplementOcrMutation.isPending}><FlaskConical size={14} /> {supplementMutation.isPending ? "Screening label..." : "Screen supplement label"}<ArrowRight size={14} /></button><div className="tool-disclaimer"><AlertTriangle size={14} /> OCR can misread small or obscured text. This screen flags concerns but cannot prove authenticity, purity, contamination status, or safety for your medical history. Verify with the manufacturer and a pharmacist or clinician.</div></div><div className="panel result-panel">{supplementMutation.data ? <><div className="analysis-header"><span className={`status-chip ${supplementMutation.data.riskLevel === "low" ? "green-chip" : "red-chip"}`}><span /> {supplementMutation.data.riskLevel.toUpperCase()} ATTENTION</span></div><span className="eyebrow">LABEL REVIEW</span><h2>{supplementMutation.data.productName}</h2><p className="analysis-lead">{supplementMutation.data.summary}</p><div className="ingredient-findings">{supplementMutation.data.findings.map(finding => <div className="ingredient-finding" key={finding.name}><div><b>{finding.name}</b><span>{finding.type}</span></div><p>{finding.note}</p></div>)}</div><div className="verification-list"><b>Verification checklist</b>{supplementMutation.data.verificationChecklist.map(item => <span key={item}><Check size={13} /> {item}</span>)}</div></> : <div className="empty-tool"><FlaskConical size={25} /><h3>Upload a label to begin</h3><p>OCR extracts readable product, serving, ingredient, warning, and batch details for your review.</p></div>}</div></div>}

    {tab === "calculator" && <div className="nutrition-feature-grid"><div className="panel nutrition-form-panel"><div className="panel-top"><div><span className="eyebrow red-text">REQUIREMENTS / ESTIMATE</span><h2>Build your daily baseline.</h2></div><Target size={18} className="muted-icon" /></div><p className="feature-copy">Use age, sex, height, weight, activity, and goal to estimate calories, macros, fibre, and water. These are educational starting points—not medical prescriptions.</p><div className="tool-form-grid"><label>AGE<input value={age} onChange={e => setAge(e.target.value)} inputMode="numeric" /></label><label>SEX<select value={sex} onChange={e => setSex(e.target.value as typeof sex)}><option value="unspecified">Not specified</option><option value="female">Female</option><option value="male">Male</option></select></label><label>HEIGHT (CM)<input value={height} onChange={e => setHeight(e.target.value)} inputMode="decimal" /></label><label>WEIGHT (KG)<input value={weight} onChange={e => setWeight(e.target.value)} inputMode="decimal" /></label><label>ACTIVITY<select value={activityLevel} onChange={e => setActivityLevel(e.target.value as typeof activityLevel)}><option value="light">Light</option><option value="moderate">Moderate</option><option value="high">High</option></select></label><label>GOAL<select value={goal} onChange={e => setGoal(e.target.value as typeof goal)}><option value="weight_gain">Weight gain</option><option value="fat_loss">Fat loss</option><option value="maintenance">Maintenance</option><option value="body_recomposition">Body recomposition</option></select></label></div><button className="btn full-width" onClick={runNutritionCalculator} disabled={nutritionMutation.isPending}><Target size={14} /> {nutritionMutation.isPending ? "Calculating..." : "Calculate daily requirements"}<ArrowRight size={14} /></button><div className="tool-disclaimer"><Info size={14} /> Estimates vary by individual. Adjust based on multi-week trends and seek professional guidance for medical or individualized concerns.</div></div><div className="panel result-panel">{nutritionMutation.data ? <><span className="eyebrow">ESTIMATED DAILY TARGETS</span><div className="metric-big"><strong>{nutritionMutation.data.calories}</strong><span>kcal</span></div><div className="metric-list"><div><span>Protein</span><b>{nutritionMutation.data.proteinGrams} g</b></div><div><span>Carbohydrates</span><b>{nutritionMutation.data.carbGrams} g</b></div><div><span>Fat</span><b>{nutritionMutation.data.fatGrams} g</b></div><div><span>Fibre / water</span><b>{nutritionMutation.data.fibreGrams} g · {Math.round(Number(weight) * 0.035 * 10) / 10} L</b></div></div><div className="signal-callout"><Check size={14} /> Use the target as a starting baseline, then monitor energy, performance, hunger, and recovery.</div></> : <div className="empty-tool"><Target size={25} /><h3>Calculate your baseline</h3><p>Complete the profile inputs to see calories, protein, carbohydrates, fat, fibre, and water targets.</p></div>}</div></div>}

    {tab === "knowledge" && <div className="knowledge-grid">{knowledge.map(item => <article className="panel knowledge-card" key={item.slug}><div className="knowledge-number">{String(knowledge.indexOf(item) + 1).padStart(2, "0")}</div><h2>{item.title}</h2><p>{item.summary}</p><div><b>DI8 PRINCIPLE</b><span>{item.guidance}</span></div></article>)}</div>}
    {tab === "daily-intake" && <div className="knowledge-grid daily-intake-grid">{dailyIntakeGuides.map((item, index) => <article className="panel knowledge-card" key={item.name}><div className="knowledge-number">{String(index + 1).padStart(2, "0")}</div><h2>{item.name}</h2><p className="daily-amount">{item.amount}</p><div><b>DI8 GUIDE</b><span>{item.note}</span></div></article>)}</div>}
    <div className="nutrition-footnote"><Target size={15} /> Nutrition education is general information, not individualized medical advice. Your trend, symptoms, medications, and history matter.</div>
  </section>;
}
