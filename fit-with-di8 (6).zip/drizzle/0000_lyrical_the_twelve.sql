CREATE TABLE `body_scans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bodyFatPercent` decimal(5,2) NOT NULL,
	`leanMassKg` decimal(6,2) NOT NULL,
	`hydrationPercent` decimal(5,2) NOT NULL,
	`source` enum('manual','body_scan') NOT NULL DEFAULT 'manual',
	`scannedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `body_scans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `food_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`mealName` varchar(160) NOT NULL,
	`calories` int NOT NULL,
	`proteinGrams` int NOT NULL,
	`carbGrams` int NOT NULL,
	`fatGrams` int NOT NULL,
	`source` enum('manual','food_scan','saved') NOT NULL DEFAULT 'manual',
	`loggedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `food_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `nutrition_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`goal` enum('fat_loss','muscle_gain','maintenance') NOT NULL DEFAULT 'maintenance',
	`heightCm` decimal(5,2) NOT NULL,
	`weightKg` decimal(6,2) NOT NULL,
	`targetCalories` int NOT NULL,
	`proteinGrams` int NOT NULL,
	`carbGrams` int NOT NULL,
	`fatGrams` int NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `nutrition_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `nutrition_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
--> statement-breakpoint
CREATE TABLE `workout_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`workoutProgramId` int,
	`title` varchar(160) NOT NULL,
	`durationMinutes` int NOT NULL,
	`loadScore` int NOT NULL,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workout_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `workout_programs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(100) NOT NULL,
	`title` varchar(160) NOT NULL,
	`description` text NOT NULL,
	`category` enum('strength','hypertrophy','conditioning','recovery','athletic') NOT NULL,
	`difficulty` enum('beginner','intermediate','advanced') NOT NULL DEFAULT 'intermediate',
	`durationMinutes` int NOT NULL,
	`setCount` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `workout_programs_id` PRIMARY KEY(`id`),
	CONSTRAINT `workout_programs_slug_unique` UNIQUE(`slug`)
);
