import {
  decimal,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const workoutPrograms = mysqlTable("workout_programs", {
  id: int("id").autoincrement().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 160 }).notNull(),
  description: text("description").notNull(),
  category: mysqlEnum("category", [
    "strength",
    "hypertrophy",
    "conditioning",
    "recovery",
    "athletic",
  ]).notNull(),
  difficulty: mysqlEnum("difficulty", ["beginner", "intermediate", "advanced"])
    .default("intermediate")
    .notNull(),
  durationMinutes: int("durationMinutes").notNull(),
  setCount: int("setCount").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const nutritionProfiles = mysqlTable("nutrition_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  goal: mysqlEnum("goal", ["fat_loss", "muscle_gain", "maintenance"])
    .default("maintenance")
    .notNull(),
  heightCm: decimal("heightCm", { precision: 5, scale: 2 }).notNull(),
  weightKg: decimal("weightKg", { precision: 6, scale: 2 }).notNull(),
  targetCalories: int("targetCalories").notNull(),
  proteinGrams: int("proteinGrams").notNull(),
  carbGrams: int("carbGrams").notNull(),
  fatGrams: int("fatGrams").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const workoutLogs = mysqlTable("workout_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  workoutProgramId: int("workoutProgramId"),
  title: varchar("title", { length: 160 }).notNull(),
  durationMinutes: int("durationMinutes").notNull(),
  loadScore: int("loadScore").notNull(),
  completedAt: timestamp("completedAt").defaultNow().notNull(),
});

export const foodLogs = mysqlTable("food_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  mealName: varchar("mealName", { length: 160 }).notNull(),
  calories: int("calories").notNull(),
  proteinGrams: int("proteinGrams").notNull(),
  carbGrams: int("carbGrams").notNull(),
  fatGrams: int("fatGrams").notNull(),
  source: mysqlEnum("source", ["manual", "food_scan", "saved"]).default("manual").notNull(),
  loggedAt: timestamp("loggedAt").defaultNow().notNull(),
});

export const bodyScans = mysqlTable("body_scans", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  bodyFatPercent: decimal("bodyFatPercent", { precision: 5, scale: 2 }).notNull(),
  leanMassKg: decimal("leanMassKg", { precision: 6, scale: 2 }).notNull(),
  hydrationPercent: decimal("hydrationPercent", { precision: 5, scale: 2 }).notNull(),
  source: mysqlEnum("source", ["manual", "body_scan"]).default("manual").notNull(),
  scannedAt: timestamp("scannedAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type WorkoutProgram = typeof workoutPrograms.$inferSelect;
export type NutritionProfile = typeof nutritionProfiles.$inferSelect;
export type WorkoutLog = typeof workoutLogs.$inferSelect;
export type FoodLog = typeof foodLogs.$inferSelect;
export type BodyScan = typeof bodyScans.$inferSelect;
