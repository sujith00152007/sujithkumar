import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  bodyScans,
  foodLogs,
  type InsertUser,
  nutritionProfiles,
  users,
  workoutLogs,
  workoutPrograms,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  updateSet.lastSignedIn ??= new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getWorkoutPrograms(category?: string) {
  const db = await getDb();
  if (!db) return [];
  if (category && category !== "all") {
    return db.select().from(workoutPrograms).where(eq(workoutPrograms.category, category as never));
  }
  return db.select().from(workoutPrograms);
}

export async function getNutritionProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(nutritionProfiles).where(eq(nutritionProfiles.userId, userId)).limit(1);
  return result[0];
}

export async function upsertNutritionProfile(input: {
  userId: number;
  goal: "fat_loss" | "muscle_gain" | "maintenance";
  heightCm: number;
  weightKg: number;
  targetCalories: number;
  proteinGrams: number;
  carbGrams: number;
  fatGrams: number;
}) {
  const db = await getDb();
  if (!db) return undefined;
  const values = {
    userId: input.userId,
    goal: input.goal,
    heightCm: input.heightCm.toFixed(2),
    weightKg: input.weightKg.toFixed(2),
    targetCalories: input.targetCalories,
    proteinGrams: input.proteinGrams,
    carbGrams: input.carbGrams,
    fatGrams: input.fatGrams,
  } as const;
  await db.insert(nutritionProfiles).values(values).onDuplicateKeyUpdate({
    set: {
      goal: values.goal,
      heightCm: values.heightCm,
      weightKg: values.weightKg,
      targetCalories: values.targetCalories,
      proteinGrams: values.proteinGrams,
      carbGrams: values.carbGrams,
      fatGrams: values.fatGrams,
    },
  });
  return getNutritionProfile(input.userId);
}

export async function createWorkoutLog(input: {
  userId: number;
  workoutProgramId?: number;
  title: string;
  durationMinutes: number;
  loadScore: number;
}) {
  const db = await getDb();
  if (!db) return undefined;
  return db.insert(workoutLogs).values(input);
}

export async function createFoodLog(input: {
  userId: number;
  mealName: string;
  calories: number;
  proteinGrams: number;
  carbGrams: number;
  fatGrams: number;
  source: "manual" | "food_scan" | "saved";
}) {
  const db = await getDb();
  if (!db) return undefined;
  return db.insert(foodLogs).values(input);
}

export async function createBodyScan(input: {
  userId: number;
  bodyFatPercent: number;
  leanMassKg: number;
  hydrationPercent: number;
  source: "manual" | "body_scan";
}) {
  const db = await getDb();
  if (!db) return undefined;
  return db.insert(bodyScans).values({
    ...input,
    bodyFatPercent: input.bodyFatPercent.toFixed(2),
    leanMassKg: input.leanMassKg.toFixed(2),
    hydrationPercent: input.hydrationPercent.toFixed(2),
  });
}

export async function getDashboardSummary(userId: number) {
  const db = await getDb();
  if (!db) return { workouts: [], meals: [], scans: [] };
  const [workouts, meals, scans] = await Promise.all([
    db.select().from(workoutLogs).where(eq(workoutLogs.userId, userId)).orderBy(desc(workoutLogs.completedAt)).limit(10),
    db.select().from(foodLogs).where(eq(foodLogs.userId, userId)).orderBy(desc(foodLogs.loggedAt)).limit(10),
    db.select().from(bodyScans).where(eq(bodyScans.userId, userId)).orderBy(desc(bodyScans.scannedAt)).limit(10),
  ]);
  return { workouts, meals, scans };
}
