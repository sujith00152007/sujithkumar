import { describe, expect, it, vi } from "vitest";
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: JSON.stringify({
      productName: "DI8 Pre-Workout",
      extractedText: "Serving Size: 1 scoop\nCaffeine 200 mg\nMilk",
      ingredients: ["Caffeine 200 mg", "Milk"],
      servingSize: "1 scoop",
      warnings: ["Contains milk"],
      batchOrExpiry: "Not readable",
      confidence: "high",
    }) } }],
  }),
}));
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const publicContext: TrpcContext = {
  user: null,
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
};

describe("fitness backend", () => {
  it("returns the handwritten performance mind-map structure", async () => {
    const caller = appRouter.createCaller(publicContext);
    const result = await caller.fitness.mindMap();

    expect(result.root).toBe("overview");
    expect(result.nodes.length).toBeGreaterThan(20);
    expect(result.nodes.some(node => node.label === "Food scanner")).toBe(true);
    expect(result.nodes.some(node => node.label === "Calorie deficit")).toBe(true);
  });

  it("calculates BMI and a directional healthy weight range", async () => {
    const caller = appRouter.createCaller(publicContext);
    const result = await caller.fitness.calculators.bmi({ heightCm: 175, weightKg: 75 });

    expect(result.bmi).toBe(24.5);
    expect(result.category).toBe("healthy range");
    expect(result.healthyWeightRangeKg.min).toBe(56.7);
    expect(result.healthyWeightRangeKg.max).toBe(76.3);
  });

  it("returns goal-aware nutrition targets", async () => {
    const caller = appRouter.createCaller(publicContext);
    const result = await caller.fitness.calculators.nutrition({
      weightKg: 75,
      goal: "muscle_gain",
      activityLevel: "moderate",
    });

    expect(result.calories).toBe(2754);
    expect(result.proteinGrams).toBe(150);
    expect(result.fatGrams).toBe(77);
    expect(result.carbGrams).toBe(365);
    expect(result.fibreGrams).toBe(28);
  });

  it("estimates body composition signals from measurements", async () => {
    const caller = appRouter.createCaller(publicContext);
    const result = await caller.fitness.scanners.bodyEstimate({
      heightCm: 175,
      weightKg: 75,
      bodyFatPercent: 18,
      waistCm: 82,
    });

    expect(result.leanMassKg).toBe(61.5);
    expect(result.fatMassKg).toBe(13.5);
    expect(result.bmi).toBe(24.5);
    expect(result.waistToHeightRatio).toBe(0.47);
  });

  it("flags common supplement label risks without claiming authenticity", async () => {
    const caller = appRouter.createCaller(publicContext);
    const result = await caller.fitness.scanners.supplementAnalyze({
      name: "Pre-workout",
      ingredients: "Proprietary blend, caffeine, yohimbine, sucralose, milk",
    });

    expect(result.riskLevel).toBe("review");
    expect(result.findings.some(finding => finding.type === "stimulant")).toBe(true);
    expect(result.findings.some(finding => finding.type === "allergen")).toBe(true);
    expect(result.verificationChecklist.length).toBeGreaterThan(2);
  });

  it("extracts structured supplement label text from an image data URL", async () => {
    const caller = appRouter.createCaller(publicContext);
    const result = await caller.fitness.scanners.supplementOcr({
      imageDataUrl: "data:image/png;base64,ZmFrZS1sYWJlbA==",
    });

    expect(result.productName).toBe("DI8 Pre-Workout");
    expect(result.ingredients).toContain("Caffeine 200 mg");
    expect(result.warnings).toContain("Contains milk");
    expect(result.confidence).toBe("high");
  });

  it("returns the requested diet knowledge topics", async () => {
    const caller = appRouter.createCaller(publicContext);
    const result = await caller.fitness.nutritionKnowledge();

    expect(result.map(item => item.slug)).toEqual([
      "calorie-deficit",
      "calorie-surplus",
      "weight-gain",
      "fat-loss",
      "weight-loss",
      "body-recomposition",
    ]);
  });
});
