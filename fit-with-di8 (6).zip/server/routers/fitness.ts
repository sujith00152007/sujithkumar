import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import {
  createBodyScan,
  createFoodLog,
  createWorkoutLog,
  getDashboardSummary,
  getNutritionProfile,
  getWorkoutPrograms,
  upsertNutritionProfile,
} from "../db";

const mindMapNodes = [
  { id: "overview", parentId: null, label: "Overview", kind: "root", description: "Your performance system at a glance." },
  { id: "workout-split", parentId: "overview", label: "Workout split", kind: "section", description: "Choose the right training intent for today's session." },
  { id: "all-sessions", parentId: "workout-split", label: "All sessions", kind: "branch", description: "Browse strength, hypertrophy, conditioning, and recovery." },
  { id: "strength", parentId: "all-sessions", label: "Strength", kind: "category", description: "Low-rep, high-intent work for force production." },
  { id: "hypertrophy", parentId: "all-sessions", label: "Hypertrophy", kind: "category", description: "Volume-focused work for muscle growth." },
  { id: "conditioning", parentId: "all-sessions", label: "Conditioning", kind: "category", description: "Build work capacity and general fitness." },
  { id: "recovery", parentId: "all-sessions", label: "Recovery", kind: "category", description: "Mobility, breathing, and readiness work." },
  { id: "athletic", parentId: "strength", label: "Athletic training", kind: "path", description: "Power, speed, and useful strength." },
  { id: "bodybuilding", parentId: "hypertrophy", label: "Bodybuilding", kind: "path", description: "Muscle-building protocols with deliberate volume." },
  { id: "muscular-endurance", parentId: "hypertrophy", label: "Muscular endurance", kind: "path", description: "Sustain quality output under fatigue." },
  { id: "heavy-lifter", parentId: "hypertrophy", label: "Heavy lifter", kind: "path", description: "Progressive overload for experienced lifters." },
  { id: "general-fitness", parentId: "conditioning", label: "General fitness", kind: "path", description: "Accessible conditioning for daily performance." },
  { id: "nutrition", parentId: "overview", label: "Nutrition", kind: "section", description: "Understand the fuel behind your output." },
  { id: "scanner", parentId: "nutrition", label: "Scanner", kind: "branch", description: "Use data capture to reduce nutrition guesswork." },
  { id: "food-scanner", parentId: "scanner", label: "Food scanner", kind: "tool", description: "Estimate calories and macros from a meal." },
  { id: "supplement-scanner", parentId: "scanner", label: "Supplement scanner", kind: "tool", description: "Record ingredients, serving size, and intent." },
  { id: "body-scanner", parentId: "scanner", label: "Body scanner", kind: "tool", description: "Track body composition signals over time." },
  { id: "bmi-calculator", parentId: "nutrition", label: "BMI calculator", kind: "calculator", description: "A directional health metric from height and weight." },
  { id: "body-composition", parentId: "bmi-calculator", label: "Body composition", kind: "metric", description: "Use trends, not a single number, to understand change." },
  { id: "protein", parentId: "bmi-calculator", label: "Protein", kind: "macro", description: "Support repair and muscle retention." },
  { id: "fibre", parentId: "bmi-calculator", label: "Fibre", kind: "macro", description: "Support digestion and satiety." },
  { id: "fat", parentId: "bmi-calculator", label: "Fat", kind: "macro", description: "Support hormones and energy density." },
  { id: "carbs", parentId: "bmi-calculator", label: "Carbs", kind: "macro", description: "Fuel training output and recovery." },
  { id: "diet-knowledge", parentId: "overview", label: "Diet knowledge", kind: "section", description: "The principles behind calorie balance." },
  { id: "calorie-deficit", parentId: "diet-knowledge", label: "Calorie deficit", kind: "principle", description: "A sustainable deficit can support fat loss." },
  { id: "calorie-surplus", parentId: "diet-knowledge", label: "Calorie surplus", kind: "principle", description: "A measured surplus can support lean mass gain." },
  { id: "fat-loss", parentId: "calorie-deficit", label: "Fat loss", kind: "outcome", description: "Prioritize consistency, protein, and recovery." },
  { id: "lean-gain", parentId: "calorie-surplus", label: "Lean gain", kind: "outcome", description: "Build gradually while tracking performance." },
] as const;

const fallbackWorkouts = [
  { id: 1, slug: "push-day-a", title: "PPL · Push Day A", description: "Chest, shoulders, triceps", category: "strength", difficulty: "intermediate", durationMinutes: 45, setCount: 18 },
  { id: 2, slug: "back-width", title: "Back width focus", description: "Lats, rhomboids, biceps", category: "hypertrophy", difficulty: "intermediate", durationMinutes: 52, setCount: 21 },
  { id: 3, slug: "leg-day", title: "Leg day annihilation", description: "Quads, hamstrings, calves", category: "conditioning", difficulty: "advanced", durationMinutes: 60, setCount: 24 },
];

const bmiCategory = (bmi: number) => {
  if (bmi < 18.5) return "underweight";
  if (bmi < 25) return "healthy range";
  if (bmi < 30) return "overweight";
  return "obesity range";
};

const nutritionKnowledge = [
  { slug: "calorie-deficit", title: "Calorie deficit", summary: "Eating fewer calories than you use over time can support weight loss.", guidance: "Start conservatively, keep protein adequate, train consistently, and review trends over several weeks." },
  { slug: "calorie-surplus", title: "Calorie surplus", summary: "Eating more calories than you use can support body-mass gain.", guidance: "Prefer a measured surplus with progressive training so more of the gain can come from lean tissue." },
  { slug: "weight-gain", title: "Weight gain", summary: "Body weight increases when average energy intake exceeds expenditure.", guidance: "Track weekly averages, strength progress, appetite, digestion, and recovery—not one daily weigh-in." },
  { slug: "fat-loss", title: "Fat loss", summary: "Fat loss is the reduction of stored body fat, usually through a sustained energy deficit.", guidance: "Use a realistic pace, preserve resistance training, prioritize protein, sleep, and adherence." },
  { slug: "weight-loss", title: "Weight loss", summary: "Weight loss includes changes in water, glycogen, food volume, muscle, and fat.", guidance: "Look at multi-week trends and waist measurements to avoid overreacting to normal fluctuations." },
  { slug: "body-recomposition", title: "Body recomposition", summary: "Recomposition aims to reduce fat while maintaining or increasing lean mass.", guidance: "It is more gradual: combine resistance training, adequate protein, recovery, and calories near maintenance." },
] as const;

export const fitnessRouter = router({
  mindMap: publicProcedure.query(() => ({
    root: "overview",
    nodes: mindMapNodes,
    source: "DI8 performance system map",
    generatedAt: new Date(),
  })),
  workouts: router({
    list: publicProcedure.input(z.object({ category: z.string().default("all") }).optional()).query(async ({ input }) => {
      const rows = await getWorkoutPrograms(input?.category);
      return rows.length > 0 ? rows : input?.category && input.category !== "all" ? fallbackWorkouts.filter(item => item.category === input.category) : fallbackWorkouts;
    }),
  }),
  calculators: router({
    bmi: publicProcedure.input(z.object({ heightCm: z.number().min(100).max(240), weightKg: z.number().min(25).max(300) })).mutation(({ input }) => {
      const bmi = Number((input.weightKg / Math.pow(input.heightCm / 100, 2)).toFixed(1));
      const healthyMin = Number((18.5 * Math.pow(input.heightCm / 100, 2)).toFixed(1));
      const healthyMax = Number((24.9 * Math.pow(input.heightCm / 100, 2)).toFixed(1));
      return { bmi, category: bmiCategory(bmi), healthyWeightRangeKg: { min: healthyMin, max: healthyMax } };
    }),
    nutrition: publicProcedure.input(z.object({ age: z.number().int().min(13).max(100).default(30), sex: z.enum(["female", "male", "unspecified"]).default("unspecified"), heightCm: z.number().min(100).max(240).default(175), weightKg: z.number().min(25).max(300), goal: z.enum(["fat_loss", "muscle_gain", "maintenance", "body_recomposition"]), activityLevel: z.enum(["light", "moderate", "high"]) })).mutation(({ input }) => {
      const base = input.sex === "male" ? 5 : input.sex === "female" ? -161 : -78;
      const bmr = 10 * input.weightKg + 6.25 * input.heightCm - 5 * input.age + base;
      const activityFactor = { light: 1.35, moderate: 1.55, high: 1.75 }[input.activityLevel];
      const goalAdjustment = { fat_loss: -300, muscle_gain: 250, maintenance: 0, body_recomposition: -50 }[input.goal];
      const calories = Math.max(1200, Math.round(bmr * activityFactor + goalAdjustment));
      const proteinGrams = Math.round(input.weightKg * (["muscle_gain", "body_recomposition"].includes(input.goal) ? 2.0 : 1.7));
      const fatGrams = Math.round((calories * 0.25) / 9);
      const carbGrams = Math.max(0, Math.round((calories - proteinGrams * 4 - fatGrams * 9) / 4));
      return { calories, proteinGrams, carbGrams, fatGrams, fibreGrams: Math.round(calories / 100) };
    }),
  }),
  scanners: router({
    supplementOcr: publicProcedure.input(z.object({ imageDataUrl: z.string().regex(/^data:image\/(jpeg|jpg|png|webp);base64,/, "Expected a JPEG, PNG, or WebP data URL").max(11_000_000) })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "You extract text from supplement label images. Return only what is visibly readable. Never invent ingredients, amounts, batch codes, or authenticity claims." },
          { role: "user", content: [
            { type: "text", text: "Read this supplement label. Extract the product name, visible ingredient panel text, serving size, warnings/allergens, and batch or expiry information. Preserve uncertainty when text is unclear." },
            { type: "image_url", image_url: { url: input.imageDataUrl, detail: "high" } },
          ] },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "supplement_label_ocr",
            strict: true,
            schema: {
              type: "object",
              properties: {
                productName: { type: "string" },
                extractedText: { type: "string" },
                ingredients: { type: "array", items: { type: "string" } },
                servingSize: { type: "string" },
                warnings: { type: "array", items: { type: "string" } },
                batchOrExpiry: { type: "string" },
                confidence: { type: "string", enum: ["low", "medium", "high"] },
              },
              required: ["productName", "extractedText", "ingredients", "servingSize", "warnings", "batchOrExpiry", "confidence"],
              additionalProperties: false,
            },
          },
        },
        maxTokens: 1200,
      });
      const content = response.choices[0]?.message.content;
      const text = Array.isArray(content) ? content.filter(part => part.type === "text").map(part => part.text).join("\n") : content;
      if (!text) throw new Error("OCR returned no readable label text");
      return JSON.parse(text) as { productName: string; extractedText: string; ingredients: string[]; servingSize: string; warnings: string[]; batchOrExpiry: string; confidence: "low" | "medium" | "high" };
    }),
    bodyEstimate: publicProcedure.input(z.object({ heightCm: z.number().min(100).max(240), weightKg: z.number().min(25).max(300), bodyFatPercent: z.number().min(2).max(70), waistCm: z.number().min(40).max(250) })).mutation(({ input }) => {
      const heightM = input.heightCm / 100;
      const bmi = Number((input.weightKg / Math.pow(heightM, 2)).toFixed(1));
      const leanMassKg = Number((input.weightKg * (1 - input.bodyFatPercent / 100)).toFixed(1));
      const fatMassKg = Number((input.weightKg - leanMassKg).toFixed(1));
      const waistToHeightRatio = Number((input.waistCm / input.heightCm).toFixed(2));
      const hydrationPercent = Number((60 - Math.max(0, input.bodyFatPercent - 15) * 0.15).toFixed(1));
      return { bodyFatPercent: input.bodyFatPercent, leanMassKg, fatMassKg, hydrationPercent, bmi, waistToHeightRatio, interpretation: waistToHeightRatio < 0.5 ? "Waist-to-height signal is below 0.50; keep tracking the trend." : "Waist-to-height signal is at or above 0.50; consider discussing context with a qualified professional." };
    }),
    supplementAnalyze: publicProcedure.input(z.object({ name: z.string().min(1).max(160), ingredients: z.string().min(3).max(12000) })).mutation(({ input }) => {
      const normalized = input.ingredients.toLowerCase();
      const findings: Array<{ name: string; type: string; note: string }> = [];
      const add = (name: string, type: string, note: string) => findings.push({ name, type, note });
      if (/proprietary blend|matrix/.test(normalized)) add("Proprietary blend", "transparency", "Individual ingredient doses may be hidden; compare the label with products that disclose amounts.");
      if (/caffeine|guarana|coffee|tea extract|yohimbine|synephrine/.test(normalized)) add("Stimulant signal", "stimulant", "Check total stimulant exposure across servings, coffee, medications, and time of day.");
      if (/milk|whey|casein|lactose|soy|soya|egg|peanut|tree nut|gluten|wheat/.test(normalized)) add("Potential allergen", "allergen", "Review the allergen statement and avoid if it conflicts with your known allergy or intolerance.");
      if (/sucralose|acesulfame|aspartame|saccharin|sorbitol|erythritol/.test(normalized)) add("Sweetener / sugar alcohol", "tolerance", "Some people experience gastrointestinal symptoms; check serving size and personal tolerance.");
      if (/dmha|dmaa|ephedra|ephedrine|sibutramine|trenbolone|prohormone/.test(normalized)) add("High-concern ingredient", "high attention", "Do not use until independently verified with a qualified clinician and local regulator guidance.");
      if (findings.length === 0) add("No common flags detected", "screening", "A clean text screen does not prove purity, identity, dose accuracy, or authenticity.");
      const highConcern = findings.some(item => item.type === "high attention");
      return { productName: input.name, riskLevel: highConcern ? "high" : findings.some(item => ["stimulant", "allergen", "transparency"].includes(item.type)) ? "review" : "low", summary: highConcern ? "A high-attention ingredient signal was found. Do not treat this screen as a safety clearance." : "The label has been screened for common ingredient signals; verify the manufacturer and serving details.", findings, verificationChecklist: ["Confirm the manufacturer, lot/batch number, and expiry date", "Check a tamper seal and compare the label with the official product page", "Look for independent quality testing or certification", "Ask a pharmacist or clinician if pregnant, medicated, or managing a condition"] };
    }),
  }),
  nutritionKnowledge: publicProcedure.query(() => nutritionKnowledge),
  dashboard: protectedProcedure.query(({ ctx }) => getDashboardSummary(ctx.user.id)),
  profile: router({
    get: protectedProcedure.query(({ ctx }) => getNutritionProfile(ctx.user.id)),
    save: protectedProcedure.input(z.object({ goal: z.enum(["fat_loss", "muscle_gain", "maintenance"]), heightCm: z.number().min(100).max(240), weightKg: z.number().min(25).max(300), targetCalories: z.number().int().min(800).max(10000), proteinGrams: z.number().int().min(0).max(500), carbGrams: z.number().int().min(0).max(1000), fatGrams: z.number().int().min(0).max(300) })).mutation(({ ctx, input }) => upsertNutritionProfile({ userId: ctx.user.id, ...input })),
  }),
  logs: router({
    workout: protectedProcedure.input(z.object({ workoutProgramId: z.number().int().optional(), title: z.string().min(1).max(160), durationMinutes: z.number().int().min(1).max(600), loadScore: z.number().int().min(0).max(100) })).mutation(({ ctx, input }) => createWorkoutLog({ userId: ctx.user.id, ...input })),
    food: protectedProcedure.input(z.object({ mealName: z.string().min(1).max(160), calories: z.number().int().min(0).max(10000), proteinGrams: z.number().int().min(0).max(500), carbGrams: z.number().int().min(0).max(1000), fatGrams: z.number().int().min(0).max(300), source: z.enum(["manual", "food_scan", "saved"]).default("manual") })).mutation(({ ctx, input }) => createFoodLog({ userId: ctx.user.id, ...input })),
    bodyScan: protectedProcedure.input(z.object({ bodyFatPercent: z.number().min(0).max(80), leanMassKg: z.number().min(1).max(300), hydrationPercent: z.number().min(0).max(100), source: z.enum(["manual", "body_scan"]).default("manual") })).mutation(({ ctx, input }) => createBodyScan({ userId: ctx.user.id, ...input })),
  }),
});
